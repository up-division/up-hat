#!/bin/bash

if grep -q 'UP-APL03' /sys/class/dmi/id/board_name
then
    sudo cp ssdt2.aml /lib/firmware/acpi-upgrades/
    sudo update-initramfs -u -k all
    echo "please reboot system to take effect!"
fi
